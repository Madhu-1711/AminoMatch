"use strict";

(() => {
  const $ = selector => document.querySelector(selector);
  const escapeHTML = value => String(value).replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
  let state = null;
  let result = null;
  let step = 0;
  let timer = null;
  let requestVersion = 0;
  let mutating = false;
  const topic = () => $('#viz-topic').value;
  const searching = () => ['linear', 'binary'].includes(topic());
  const names = () => new Map(state.foods.map(food => [food.id, food.name]));
  const limit = () => !result ? 0 : searching() ? result.search.steps.length : topic() === 'tree' ? result.traversal.length : topic() === 'bfs' ? result.bfs.order.length : topic() === 'list' ? result.linked.length : 0;

  async function api(path, payload) {
    const response = await fetch(path, payload === undefined ? {} : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'The server could not load the data');
    return data;
  }

  function pause() {
    clearInterval(timer);
    timer = null;
    $('#viz-play').textContent = '▶';
    $('#viz-play').setAttribute('aria-label', 'Play traversal');
    $('#viz-play').title = 'Play traversal';
  }

  function sequence(values, visitedCount) {
    return values.map((value, index) => `<span class="${index === visitedCount - 1 ? 'current' : index < visitedCount ? 'visited' : ''}"><b>${index + 1}</b> ${escapeHTML(value)}</span>`).join('');
  }

  function nodeClass(value, order) {
    const index = order.indexOf(value);
    return index >= 0 && index < step ? index === step - 1 ? 'current' : 'visited' : '';
  }

  function treeDiagram() {
    const positions = [];
    const edges = [];
    let column = 0;
    function place(node, depth) {
      if (!node) return null;
      const left = place(node.left, depth + 1);
      const right = place(node.right, depth + 1);
      const horizontal = left && right ? (left.x + right.x) / 2 : left ? left.x + 81 : right ? right.x - 81 : column++ * 200 + 166;
      const point = { name: node.name, x: horizontal, y: depth * 115 + 48 };
      positions.push(point);
      if (left) edges.push([point, left, 'L']);
      if (right) edges.push([point, right, 'R']);
      return point;
    }
    place(result.tree, 0);
    const minimum = Math.min(...positions.map(point => point.x)) - 85;
    const width = Math.max(340, Math.max(...positions.map(point => point.x)) - minimum + 85);
    const height = Math.max(...positions.map(point => point.y), 48) + 58;
    const lines = edges.map(([parent, child, side]) => `<g><path d="M${parent.x},${parent.y + 32} L${child.x},${child.y - 32}"/><text x="${(parent.x + child.x) / 2}" y="${(parent.y + child.y) / 2 - 6}">${side}</text></g>`).join('');
    const nodes = positions.map(point => {
      const visit = result.traversal.indexOf(point.name) + 1;
      return `<foreignObject x="${point.x - 73}" y="${point.y - 32}" width="146" height="70"><div xmlns="http://www.w3.org/1999/xhtml" class="viz-tree-node ${nodeClass(point.name, result.traversal)}"><small>${visit <= step ? `VISIT ${visit}` : point.name === result.tree.name ? 'ROOT' : 'NOT VISITED'}</small><span>${escapeHTML(point.name)}</span></div></foreignObject>`;
    }).join('');
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${minimum} 0 ${width} ${height}" width="${width}" height="${height}" class="viz-tree-svg" role="img" aria-label="Food binary search tree"><title>Food binary search tree. Highlighted nodes follow the selected Python traversal.</title><g class="viz-tree-lines">${lines}</g>${nodes}</svg>`;
  }

  function graphDiagram(frame) {
    const ids = Object.keys(result.graph);
    const size = Math.max(760, ids.length * 48);
    const radius = size / 2 - 108;
    const positions = new Map(ids.map((id, index) => {
      const angle = 2 * Math.PI * index / ids.length - Math.PI / 2;
      return [id, { x: size / 2 + Math.cos(angle) * radius, y: size / 2 + Math.sin(angle) * radius, number: index + 1 }];
    }));
    const discovery = new Set(result.bfs.discovery_edges.map(edge => edge.join('|')));
    const visited = new Set(result.bfs.order.slice(0, step));
    const reached = new Set([...visited, ...frame.queue]);
    const labels = names();
    const edges = ids.flatMap(id => result.graph[id].filter(neighbor => positions.get(id).number < positions.get(neighbor).number).map(neighbor => {
      const first = positions.get(id), second = positions.get(neighbor);
      const isDiscovery = reached.has(id) && reached.has(neighbor) && (discovery.has(`${id}|${neighbor}`) || discovery.has(`${neighbor}|${id}`));
      return `<line x1="${first.x}" y1="${first.y}" x2="${second.x}" y2="${second.y}" class="${isDiscovery ? 'discovery' : ''}"/>`;
    })).join('');
    const nodes = ids.map(id => {
      const point = positions.get(id);
      const status = id === frame.current ? 'current' : visited.has(id) ? 'visited' : frame.queue.includes(id) ? 'pending' : '';
      const visit = result.bfs.order.indexOf(id) + 1;
      return `<g class="viz-graph-node ${status}"><title>${escapeHTML(labels.get(id))}${visited.has(id) ? `, visit ${visit}` : ''}</title><circle cx="${point.x}" cy="${point.y}" r="23"/><text x="${point.x}" y="${point.y + 5}">${point.number}</text><foreignObject x="${point.x - 70}" y="${point.y + 28}" width="140" height="62"><div xmlns="http://www.w3.org/1999/xhtml" class="viz-graph-label">${escapeHTML(labels.get(id))}${visited.has(id) ? `<small>Visit ${visit}</small>` : ''}</div></foreignObject></g>`;
    }).join('');
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" width="${size}" height="${size}" class="viz-graph-svg" role="img" aria-label="Undirected food pairing graph"><title>Numbered foods correspond to the adjacency list. Dark lines are BFS discovery edges.</title><g class="viz-graph-edges">${edges}</g>${nodes}</svg>`;
  }

  function snapshotLabel(meal) {
    const labels = names();
    return meal.length ? meal.map(portion => `${labels.get(portion.food_id)} (${portion.grams} g)`).join(' + ') : 'Empty snapshot';
  }

  function stackDiagram(values) {
    return `<div class="viz-stack" role="list" aria-label="Stack, top first">${values.length ? values.map((value, index) => `<div class="viz-stack-node ${index === 0 ? 'current' : ''}" role="listitem"><small>${index === 0 ? 'TOP' : index === values.length - 1 ? 'BOTTOM' : `DEPTH ${index + 1}`}</small><strong>${escapeHTML(value)}</strong></div>`).join('') : '<div class="viz-empty">Empty stack</div>'}</div>`;
  }

  function renderSearch() {
    const search = result.search;
    const binary = search.algorithm === 'binary';
    const frame = step ? search.steps[step - 1] : null;
    const complete = step === search.steps.length;
    const current = frame ? binary ? frame.mid : frame.index : -1;
    const checked = new Set(search.steps.slice(0, step).map(entry => binary ? entry.mid : entry.index));
    const low = frame && binary ? frame.low : 0;
    const high = frame && binary ? frame.high : search.items.length - 1;
    const outcome = complete ? search.found ? `Found at index ${current}: ${search.found.name}` : 'Not found' : frame ? `Compare index ${current}: ${frame.name}` : 'Ready';
    $('#viz-status').textContent = `${outcome} · ${step} comparisons · Target: ${search.target}`;
    $('#viz-diagram').innerHTML = `<div class="viz-search"><h2>${binary ? 'Sorted food array · A to Z' : 'Food list · original order'}</h2><div class="viz-search-array" role="list" aria-label="${binary ? 'Sorted search array' : 'Linear search list'}">${search.items.map((name, index) => {
      const excluded = binary && (index < low || index > high || (complete && !search.found));
      const status = index === current ? frame.matched ? 'found' : 'current' : excluded ? 'excluded' : checked.has(index) ? 'visited' : '';
      const pointers = binary ? [index === low ? 'LOW' : '', index === current ? 'MID' : '', index === high ? 'HIGH' : ''].filter(Boolean).join(' / ') : index === current ? 'CURRENT' : '';
      return `<div class="viz-search-node ${status}" role="listitem" data-index="${index}"><small>INDEX ${index}</small><strong>${escapeHTML(name)}</strong><span class="viz-search-pointer">${pointers || '&nbsp;'}</span></div>`;
    }).join('')}</div></div>`;
    $('#viz-sequence').innerHTML = sequence(search.steps.map(entry => entry.name), step);
    const decision = !frame ? 'No comparisons yet' : frame.matched ? 'Exact match' : binary ? frame.comparison === 'less' ? 'Midpoint is before target: continue right' : 'Midpoint is after target: continue left' : 'No match: continue to the next food';
    const nextRange = frame && binary && !frame.matched ? frame.next_low > frame.next_high ? 'Empty range' : `${frame.next_low} to ${frame.next_high}` : '';
    $('#viz-details').innerHTML = `<div class="viz-search-summary"><span><small>COMPARISON</small><strong>${escapeHTML(decision)}</strong></span>${nextRange ? `<span><small>NEXT RANGE</small><strong>${nextRange}</strong></span>` : ''}<span><small>RESULT</small><strong>${complete ? search.found ? 'Found' : 'Not found' : 'In progress'}</strong></span></div>`;
  }

  function render() {
    if (!result) return;
    const selected = topic();
    const total = limit();
    step = Math.min(step, total);
    $('#viz-position').textContent = `${step} / ${total}`;
    $('#viz-step').max = total;
    $('#viz-step').value = step;
    $('#viz-prev').disabled = $('#viz-reset').disabled = step === 0;
    $('#viz-next').disabled = step === total;
    $('#viz-play').disabled = total === 0;
    const mutable = ['stack', 'queue'].includes(selected);
    $('#viz-mutations').hidden = !mutable;
    $('#viz-queue-actions').hidden = selected !== 'queue';
    $('#viz-playback').hidden = $('#viz-legend').hidden = mutable;
    $('#viz-sequence-title').hidden = mutable;
    $('#viz-push').disabled = mutating || state.meal.length >= 30 || state.undo_count >= 200;
    $('#viz-pop').disabled = mutating || !state.undo_count;
    $('#viz-enqueue').disabled = mutating || !state.meal.length || state.queue.length >= 20;
    $('#viz-dequeue').disabled = mutating || !state.queue.length;
    $('#viz-workspace').classList.toggle('viz-graph-workspace', selected === 'bfs');
    $('#viz-sequence-title').textContent = selected === 'bfs' ? 'BFS visit sequence' : selected === 'list' ? 'List traversal sequence' : `${$('#viz-order').value[0].toUpperCase()}${$('#viz-order').value.slice(1)} sequence`;
    if (searching()) $('#viz-sequence-title').textContent = 'Comparison sequence';
    $('#viz-sequence').innerHTML = '';
    $('#viz-details').innerHTML = '';
    if (searching()) {
      renderSearch();
    } else if (selected === 'tree') {
      const rules = { inorder: 'Left → Root → Right', preorder: 'Root → Left → Right', postorder: 'Left → Right → Root' };
      $('#viz-status').textContent = `${rules[$('#viz-order').value]} · ${step ? `Visit ${step}: ${result.traversal[step - 1]}` : 'Ready at the beginning'}${step === total ? ' · Complete' : ''}`;
      $('#viz-diagram').innerHTML = treeDiagram();
      $('#viz-sequence').innerHTML = sequence(result.traversal, step);
    } else if (selected === 'bfs') {
      const frame = result.bfs.steps[step];
      const labels = names();
      const ids = Object.keys(result.graph);
      const discovered = frame.discovered.map(id => labels.get(id));
      $('#viz-status').textContent = `${frame.current ? `Visited ${labels.get(frame.current)}` : `Start: ${labels.get(result.bfs.order[0])}`} · Newly queued: ${discovered.join(', ') || 'none'}${step === total ? ` · Complete: ${total} of ${ids.length} foods reachable` : ''}`;
      $('#viz-diagram').innerHTML = graphDiagram(frame);
      $('#viz-sequence').innerHTML = sequence(result.bfs.order.map(id => labels.get(id)), step);
      $('#viz-details').innerHTML = `<h2>BFS queue <small>front → back</small></h2><div class="viz-queue">${frame.queue.length ? frame.queue.map(id => `<span>${ids.indexOf(id) + 1}. ${escapeHTML(labels.get(id))}</span>`).join('<b aria-hidden="true">→</b>') : '<span>Empty</span>'}</div><h2>Adjacency list</h2><div class="viz-adjacency">${ids.map((id, index) => `<div class="${id === frame.current ? 'current' : ''}"><strong><b class="viz-node-id">${index + 1}</b>${escapeHTML(labels.get(id))}</strong><div class="viz-neighbors" aria-label="Neighbors of ${escapeHTML(labels.get(id))}">${result.graph[id].map(neighbor => `<span aria-hidden="true">→</span><span class="viz-neighbor" title="${escapeHTML(labels.get(neighbor))}"><b>${ids.indexOf(neighbor) + 1}</b><span>${escapeHTML(labels.get(neighbor))}</span></span>`).join('') || '<span>∅ No connections</span>'}</div></div>`).join('')}</div>`;
    } else if (selected === 'list') {
      $('#viz-status').textContent = step ? `Node ${step} of ${total}: ${result.linked[step - 1]}${step === total ? ' · Next: None' : ''}` : `HEAD → TAIL · ${total} nodes`;
      $('#viz-diagram').innerHTML = `<div class="viz-chain" role="list" aria-label="Singly linked list">${result.linked.map((name, index) => `<div class="viz-chain-node ${nodeClass(name, result.linked)}" role="listitem"><small>${index === 0 ? 'HEAD' : `NODE ${index + 1}`}${index === total - 1 ? ' · TAIL' : ''}</small><strong>${escapeHTML(name)}</strong><span>next →</span></div><b aria-hidden="true">→</b>`).join('')}<span>None</span></div>`;
      $('#viz-sequence').innerHTML = sequence(result.linked, step);
    } else if (mutable) {
      $('#viz-status').textContent = selected === 'stack' ? `LIFO · ${result.history.length} saved snapshots · Top is next to pop` : `FIFO · ${state.queue.length} / 20 queued snapshots · Front is next to dequeue`;
      const current = `<section><h2>Current snapshot <small>${state.meal.length} / 30 portions</small></h2><p class="viz-current-snapshot">${escapeHTML(snapshotLabel(state.meal))}</p></section>`;
      $('#viz-diagram').innerHTML = selected === 'stack' ? `<div class="viz-structure-layout"><section><h2>Undo stack</h2>${stackDiagram(result.history.map(snapshotLabel))}</section>${current}</div>` : `<div class="viz-structure-layout viz-queue-layout"><section><h2>Snapshot queue</h2><div class="viz-chain" role="list" aria-label="Queue, front to rear">${state.queue.length ? state.queue.map((job, index) => `<div class="viz-chain-node ${index === 0 ? 'current' : 'pending'}" role="listitem"><small>${index === 0 ? 'FRONT' : ''}${index === state.queue.length - 1 ? ' REAR' : ''}</small><strong>Job #${job.id}</strong><span>${job.portions} portions</span></div>${index < state.queue.length - 1 ? '<b aria-hidden="true">→</b>' : ''}`).join('') : '<div class="viz-empty">Empty queue</div>'}</div></section>${current}</div>`;
    }
  }

  async function load() {
    pause();
    const version = ++requestVersion;
    result = null;
    step = 0;
    $('#viz-content').hidden = true;
    $('#viz-content').setAttribute('aria-busy', 'true');
    $('#viz-error').hidden = true;
    const selected = topic();
    $('#viz-order-field').hidden = selected !== 'tree';
    $('#viz-start-field').hidden = selected !== 'bfs';
    $('#viz-search-form').hidden = !searching();
    try {
      const nextState = await api('/api/state');
      if (version !== requestVersion) return;
      state = nextState;
      $('#viz-food-names').innerHTML = state.foods.map(food => `<option value="${escapeHTML(food.name)}"></option>`).join('');
      const previous = $('#viz-start').value;
      $('#viz-start').innerHTML = state.foods.map(food => `<option value="${escapeHTML(food.id)}">${escapeHTML(food.name)}</option>`).join('');
      if (state.foods.some(food => food.id === previous)) $('#viz-start').value = previous;
      const previousFood = $('#viz-food').value;
      $('#viz-food').innerHTML = $('#viz-start').innerHTML;
      if (state.foods.some(food => food.id === previousFood)) $('#viz-food').value = previousFood;
      const params = new URLSearchParams({ order: $('#viz-order').value, start: $('#viz-start').value });
      const data = await api(`/api/structures?${params}`);
      if (version !== requestVersion) return;
      if (searching()) {
        const searchParams = new URLSearchParams({ algorithm: selected, target: $('#viz-target').value });
        data.search = await api(`/api/search?${searchParams}`);
        if (version !== requestVersion) return;
      }
      result = data;
      render();
      $('#viz-content').hidden = false;
    } catch (error) {
      if (version !== requestVersion) return;
      $('#viz-error').textContent = `Could not load the visualizer: ${error.message}`;
      $('#viz-error').hidden = false;
    } finally {
      if (version === requestVersion) $('#viz-content').setAttribute('aria-busy', 'false');
    }
  }

  function move(next) {
    pause();
    step = Math.max(0, Math.min(limit(), next));
    render();
  }

  function play() {
    if (timer) return pause();
    if (!result) return;
    if (step === limit()) step = 0;
    $('#viz-play').textContent = 'Ⅱ';
    $('#viz-play').setAttribute('aria-label', 'Pause traversal');
    $('#viz-play').title = 'Pause traversal';
    timer = setInterval(() => {
      step++;
      render();
      if (step >= limit()) pause();
    }, Number($('#viz-speed').value));
  }

  async function mutate(path, payload, message) {
    if (mutating || !result) return;
    mutating = true;
    pause();
    render();
    $('#viz-topic').disabled = $('#viz-refresh').disabled = true;
    $('#viz-error').hidden = true;
    try {
      const data = await api(path, payload);
      document.dispatchEvent(new Event('aminomatch:changed'));
      $('#viz-operation').textContent = data.processed ? `Dequeued job #${data.processed.id}. ${data.processed.analysis.protein_g} g protein in saved snapshot.` : message;
      await load();
    } catch (error) {
      $('#viz-error').textContent = error.message;
      $('#viz-error').hidden = false;
    } finally {
      mutating = false;
      $('#viz-topic').disabled = $('#viz-refresh').disabled = false;
      if (result) render();
    }
  }

  ['#viz-topic', '#viz-order', '#viz-start'].forEach(selector => $(selector).addEventListener('change', () => { $('#viz-operation').textContent = ''; load(); }));
  document.querySelectorAll('[data-viz-order]').forEach(button => button.addEventListener('click', () => {
    $('#viz-order').value = button.dataset.vizOrder;
    document.querySelectorAll('[data-viz-order]').forEach(option => option.setAttribute('aria-pressed', String(option === button)));
    load();
  }));
  $('#viz-refresh').addEventListener('click', load);
  $('#viz-search-form').addEventListener('submit', event => { event.preventDefault(); load(); });
  $('#viz-sample-form').addEventListener('submit', event => { event.preventDefault(); mutate('/api/meal', { action: 'add', food_id: $('#viz-food').value, grams: 100 }, 'Previous snapshot pushed; 100 g added to current snapshot.'); });
  $('#viz-pop').addEventListener('click', () => mutate('/api/meal', { action: 'undo' }, 'Top snapshot popped and restored.'));
  $('#viz-enqueue').addEventListener('click', () => mutate('/api/queue', { action: 'enqueue' }, 'Current snapshot copied to the rear of the queue.'));
  $('#viz-dequeue').addEventListener('click', () => mutate('/api/queue', { action: 'process' }, 'Front snapshot dequeued.'));
  $('#viz-next').addEventListener('click', () => move(step + 1));
  $('#viz-prev').addEventListener('click', () => move(step - 1));
  $('#viz-reset').addEventListener('click', () => move(0));
  $('#viz-step').addEventListener('input', event => move(Number(event.target.value)));
  $('#viz-play').addEventListener('click', play);
  $('#viz-speed').addEventListener('change', () => { if (timer) { pause(); play(); } });
  document.addEventListener('visibilitychange', () => { if (document.hidden) pause(); });
  document.addEventListener('aminomatch:view', event => {
    if (event.detail === 'visualizer') load();
    else pause();
  });
})();