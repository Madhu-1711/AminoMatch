# AminoMatch

**Beyond the protein count.** A Python data-structures project that explores essential amino acids in individual foods and meals. Phases 1, 2 and 3 are implemented; Phase 4 is reserved for later requirements.

## Run locally

Requires Python 3.11+ (developed with Python 3.13). Flask serves both the website and API; no Node.js or frontend build is required.

1. Create a virtual environment with `python -m venv .venv`.
2. Install dependencies with `.venv\Scripts\python.exe -m pip install -r requirements.txt` on Windows.
3. Start with `.venv\Scripts\python.exe app.py`.
4. Visit **http://127.0.0.1:5000**. Stop the server with Ctrl+C.

On macOS/Linux, use `.venv/bin/python` in place of `.venv\Scripts\python.exe`.

The current workspace already has a configured virtual environment. In VS Code, use **Terminal → Run Task → AminoMatch: Run**. The test task runs the standard-library unittest suite. No debugger or extra editor extensions are required.

## Website

- **Meal builder:** add edible serving weights, remove portions, undo changes, and inspect nine amino acid reference groups, limiting group, essential amino acid total and protein total.
- **Food library:** searchable/filterable individual food profiles, CSV template download and validated dataset replacement.
- **Linear structures:** linked-list nodes, stack-backed undo, FIFO meal analysis, infix/postfix conversion and iterative/recursive operation counts.
- **Trees & graphs:** binary food hierarchy, three traversal orders, exact-name binary-search trace, adjacency lists and BFS.
- **Phase 3: Analysis:** merge-sorted amino acid rankings, linear search and a max-heap food priority queue, with graphical playback.
- **Getting started:** food-explorer workflows. Phase 4 remains planned, without assumed functionality.
- **How it works:** formulas, adult reference values and limitations.

### A short demonstration

1. Select **Try lentils + brown rice**. This replaces the meal with 100 g of each and pushes the old meal to the undo stack.
2. Remove one portion and observe the lowest-coverage group. Use **Undo** to restore it.
3. Queue a meal, change it, and queue again. In Phase 1, process the jobs in order; each retains its original snapshot.
4. Convert `(9 + 2.6) * 2`: postfix `9 2.6 + 2 *`, result `23.2`.
5. In Phase 2, change traversal order and search for `Lentils (cooked)`. Change the BFS start node.
6. Download the CSV template, edit it and import it from the Food library. Invalid imports leave all previous state unchanged.

## Phase requirements and implementations

| Phase | Requirement | Implementation |
| --- | --- | --- |
| 1 | Dataset input | UTF-8 CSV, strict schema and atomic validation in [nutrition.py](nutrition.py) |
| 1 | Linked list | `Node`, `LinkedList`; authoritative food storage |
| 1 | Stack | Linked `Stack`; meal history, operator stack and postfix value stack |
| 1 | Queue | Linked `Queue`; saved-meal FIFO analysis and BFS frontier |
| 1 | Infix / postfix | Shunting-yard conversion with token trace and postfix evaluation |
| 1 | Basic efficiency | Iterative and recursive sum, additions/calls and time/space explanation |
| 2 | Binary tree | `BinarySearchTree`, alphabetic food hierarchy |
| 2 | Tree traversal | Inorder, preorder, postorder |
| 2 | Binary search | Search a pre-sorted random-access array; low/mid/high trace |
| 2 | Graph representation | Undirected food-pair adjacency lists |
| 2 | One graph traversal | Breadth-first search; queue plus visited set |
| 3 | Linear search | Exact case-insensitive name search over ranked foods, with comparison trace |
| 3 | Sorting technique | Explicit stable merge sort with ascending/descending order and merge frames |
| 3 | Searching/sorting for analysis | Rank foods by amino-acid measure, filter category, find rank, inspect count/mean/min/max |
| 3 | Heap priority | Array-backed max-heap, sift-up insertion, sift-down extraction, FIFO ties |
| 4 | Not yet supplied | Planned only |

Algorithms are in [structures.py](structures.py), scoring and validation in [nutrition.py](nutrition.py), and API integration in [app.py](app.py). All demonstrations invoke Python endpoints; the browser renders the results.

### Complexity notes

- Linked append, linked stack push/pop and queue enqueue/dequeue: O(1). Food lookup: O(n).
- Saving or restoring a meal state involves up to O(m) meal data, separate from stack pointer operations. History is capped at 200 edits.
- Meal analysis with linked-list food lookups: O(mn), where m is portions and n is foods; amino-acid count is fixed.
- Infix conversion/evaluation: O(t) time and O(t) space for t tokens. The displayed full output trace can occupy O(t²) space; expressions are capped at 200 characters.
- Iterative/recursive sum: O(n) time; O(1)/O(n) auxiliary space. Recursion uses an index, not repeated slicing. The CSV limit keeps recursion well below Python's usual stack limit.
- Binary search: O(log n) comparisons after O(n log n) sorting and O(n) array materialization. Searching the linked list directly would not provide efficient midpoint access.
- Median-first BST insertion produces a balanced initial hierarchy; it is not AVL/self-balancing. Construction is O(n log n), traversal O(n); ordinary BST insertion is O(h), worst-case O(n).
- Pair graph construction: O(n²). Edge rule: 100 g of each food together scores more than 5 percentage points above the weaker individual food. This does not guarantee mutual improvement or complete reference coverage.
- BFS: O(V + E) time, O(V) additional visited/queue space. Disconnected foods outside the starting component are not visited.
- Phase 3 linear search: O(n) worst-case time, O(1) working space; optional displayed comparison trace uses O(n) space.
- Stable merge sort: O(n log n) time and O(n) auxiliary space. Teaching frames retain full arrays after merges, costing O(n²) trace storage, bounded by the 250-food dataset limit. Equal values preserve source order, including descending sorts.
- Max-heap insertion/extraction: O(log n), root lookup O(1), stored queue O(n). Full-array teaching traces add O(n log n) copying per operation. Numeric priorities come from the server's food analysis, not browser input.
- These bounds describe the algorithms, not the entire HTTP request. Preparing all food profiles uses the existing linked-list lookups (O(n²)); trace generation and serialization add their own costs.

### Phase 3 demonstration

Open **Phase 3: Analysis**, or `http://127.0.0.1:5000/#phase3`.

1. Choose **Lysine (mg / 100 g)**, highest first, and **Analyze**. Inspect ranked foods and the summary. Select **Merge sort** and step through the Python merge frames.
2. Enter `Lentils (cooked)`, then Analyze. Select **Linear search** and play the comparisons in ranked order. With the starter dataset and no category filter, lentils are rank 7 by lysine.
3. Choose **Grains** and Analyze with the same target: search reports no exact match within that category. Search ignores case and surrounding whitespace but does not do partial-name matching.
4. Select **Max-heap priority queue**, choose a priority measure and insert foods. Extract maximum removes the highest-priority entry, independently of insertion order. Equal priorities leave oldest first; repeated foods are permitted and have separate entry numbers.
5. The tree and array show the same heap state. Replay shows append/root removal and each sift operation, including temporary states before the heap invariant is restored. Mutations always act on the live queue, not the replay frame.

Analysis measures are the reference-pattern score, nine-essential-amino-acid total, or any individual essential amino acid. Amount measures are mg per 100 g food; the pattern score is a percentage of the adult reference. Rankings and priorities are not personalized dietary recommendations. Scores/totals use the same rounded values as the existing food profiles.

The priority queue holds at most 20 entries per browser session. Its measure cannot change until the queue is empty. It is separate from the FIFO meal-review queue, does not change your meal, and is cleared by a dataset import/reset or server restart. Only the latest operation's replay is retained in the browser.

Phase 3 APIs: `GET /api/phase3?metric=lysine_mg&direction=descending&category=Grains&target=Oats%20(dry)`; `POST /api/priority` with action `push` (food_id + metric), `pop`, or `clear`. The server returns the ordering and traces; JavaScript only renders them.

## Nutrition model and honesty

**The 12 starter foods contain plausible illustrative values, not verified food-composition measurements. Do not use them for dietary decisions.** Uploaded values are also not independently verified by the application.

Dataset quantities refer to **100 g edible food in the named preparation state**. Protein is in **grams**, amino acids in **milligrams**. Raw and cooked foods are not interchangeable.

- Serving amount (mg) = source amount (mg per 100 g) × serving weight (g) / 100.
- Group coverage (%) = total group amount (mg) / [total protein (g) × reference value (mg/g)] × 100.
- Pattern score = lowest group coverage. The “Meets the reference pattern” label requires every group to meet its target; a rounded displayed percentage does not determine the label.
- The essential amino acid total sums only the nine essential amino acids. Cysteine and tyrosine contribute to the two combined reference groups, but not to that total.

Reference: **WHO/FAO/UNU (2007), Protein and amino acid requirements in human nutrition, WHO Technical Report Series 935**, adult scoring pattern: histidine 15, isoleucine 30, leucine 59, lysine 45, methionine+cysteine 22, phenylalanine+tyrosine 38, threonine 23, tryptophan 6 and valine 39 mg/g protein.

This is **not** daily-intake coverage, DIAAS, PDCAAS, a digestibility measure, or a clinical assessment. Doubling the same food doubles its amino acid amounts but leaves its proportional score unchanged. Complementary foods do not necessarily need to be eaten in the same meal. Replace the illustrative dataset with verified measurements and retain source identifiers in a separate research record before scientific use.

### CSV input contract

Use the exact column names and ordering in [data/foods.csv](data/foods.csv). Fields: `id`, `name`, `category`, `protein_g`, followed by eleven `_mg` amino-acid fields (nine essential plus cysteine and tyrosine).

- Maximum 250 food rows and 1 MB request size.
- Unique lowercase alphanumeric/hyphen IDs (1–50 characters); unique case-insensitive food names (1–80); category (1–40).
- Protein greater than zero and no more than 100 g per 100 g food.
- All amino values present, finite and nonnegative; recorded zero is valid, missing data is not zero.
- Total recorded amino-acid mass must not exceed protein mass by more than 5%, allowing rounding.
- Invalid headers, duplicate foods, malformed rows and invalid UTF-8 are rejected.
- Imports **replace** the dataset and clear meal/history/FIFO queue/priority queue only after successful validation; confirmation is requested first. The source CSV on disk is never overwritten.

## Test

Run `.venv\Scripts\python.exe -m unittest discover -s tests -v` or the **AminoMatch: Test** task.

Tests cover structural invariants, empty cases, expression errors, traversal order, binary search, cyclic/disconnected BFS, serving scaling, combined groups, CSV validation, API errors, undo, queue snapshots and browser-session isolation.

Phase 3 tests additionally cover linear-search hits/misses, merge-sort stability/directions/traces, heap invariants and priority ties, ranking/category analysis, invalid inputs, capacity limits and priority reset/isolation. Current suite: 37 tests.

## Scope and persistence

This is a **local educational prototype**. Browser sessions hold separate in-memory datasets, meals, history and queues. Page refresh preserves a session while the server is running; restarting the server resets everything. Up to 64 recently used sessions are retained; the oldest is evicted at capacity. Clearing cookies also starts a fresh workspace. There is no database, authentication, background worker or deployment configuration. Queue jobs run when you press **Process next**, not automatically.

The Flask development server binds only to 127.0.0.1 with debug mode off. Do not expose it as a public production service. The frontend uses local CSS/JavaScript and CSS illustrations, without third-party CDNs or external image assets.